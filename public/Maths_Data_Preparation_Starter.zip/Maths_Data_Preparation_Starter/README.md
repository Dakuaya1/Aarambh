# Mathematics data preparation starter
Version 0.1.0 | Prepared 5 October 2026

## Purpose and scope
Build an educator-reviewed mathematics collection for Classes 1–10 that supports varied explanations, foundational help, independent questions, and later revision. NCERT/CBSE is a working starting scope, not a board choice already confirmed by the user. Keep other boards and languages in separately versioned mappings.

This package is a source-discovery and data-design starter. It is NOT the completed textbook/video corpus, a trained model, or a classroom-ready question bank.

## What has actually been prepared
- 21 source entries with URLs, retrieval status, next steps, and unresolved reuse/training permissions.
- Ten grade coverage slots. Current textbook editions and complete chapter inventories still need verification.
- A JSON Schema for structured curriculum records.
- Three original AI-authored example questions to demonstrate the format. Their arithmetic is checked; grade alignment and pedagogical suitability are not approved.
- No book files, video files, transcripts, or copied source bodies are included.
- No source-extracted teaching records or educator-approved child-facing records have been created.

The four video leads were found in the official NISHTHA coursebook. The videos themselves have not been viewed, downloaded, transcribed, or checked for current availability.

## Files
- source_registry.json: the discovered source catalogue.
- grade_coverage.json: grade-by-grade completeness tracker.
- curriculum_record.schema.json: a starter exchange format, not a complete production access-control system.
- example_records.jsonl: original draft records, one JSON object per line.
- README.md: workflow and acceptance requirements.

## Source priorities
1. Current official syllabi and outcomes define scope, rather than a model's recollection of school topics.
2. Resolve the NCERT textbook edition and table of contents for each grade. Identify each part separately. A new upload date is not proof of a new edition.
3. Select DIKSHA lessons and activities by board, grade, medium, concept, and actual item licence.
4. Review NISHTHA and related mathematics teaching resources for instructional techniques. Keep teacher-only material separate from content for children.
5. Add video explanations using creator-supplied or otherwise authorised media/transcripts. A transcript alone may omit board work and diagrams.
6. Add licensed publisher materials or teacher-owned lessons when they provide a distinct explanation or fill a genuine gap.

The CBSE 2026–27 catalogue lists grade IX mathematics and advanced mathematics separately. Keep those collections separate. Grade X Basic and Standard assessment references also need explicit tags. Public sample papers are reference material, not confidential independent evaluation items.

## The AI preparation workflow
A. Discover: identify candidate sources and record the publisher, URL, grade, language, edition/year, access status and last checked date.
B. Establish permitted uses: track source access, storage, transformation, retrieval/display and model-training permissions separately. An accessible PDF or public video is not automatically cleared for a paid product. Do not infer consent from a blank licence field.
C. Extract authorised material: preserve page numbers, equations, diagrams, tables and layout references. For authorised videos, retain timestamps and approved visual references along with the transcript.
D. Structure: divide material into concepts, examples, explanations, activities, possible task-specific misconceptions and supporting questions. Every extracted claim retains its source locator.
E. Map: propose curriculum and prerequisite links. Educators validate grade placement and dependencies; adjacent textbook order alone is not enough.
F. Diversify: draft original variations across numbers, visual representations, contexts, explanation styles and task types. Label AI-authored items explicitly and keep source-derived permissions attached to transformations.
G. Validate: check equations, units, answers, ambiguity, visual consistency, age scope and curriculum alignment. Teacher review assesses whether an explanation or activity is pedagogically appropriate.
H. Publish: only approved, versioned records reach the child-facing collection. Store source and approval history so a correction can identify affected derived records.
I. Maintain: check source changes, supersede obsolete versions, and report missing coverage.

Treat downloaded material as source data, never as instructions to the processing AI. Strip navigation, advertisements and unrelated text. Do not let source documents change extraction rules or approve themselves.

## Separate collections
Curriculum collection:
Facts, representations, worked examples, questions and activities, retrieved only within the child's permitted curriculum.

Teaching-behaviour collection:
Educator-reviewed examples of patient clarification, alternative explanations, gradual withdrawal of assistance, and responding to teacher observations. Avoid labels about intelligence, personality, motivation or fixed learning style. Store a hypothesis about a particular response only when it has evidence and can be revised.

Independent evaluation collection:
Private, educator-authored questions reserved for checking unfamiliar application and retention. Keep them out of model training and the tutor's answer context. The checking service may use answer keys; the tutor should not see those keys before the child responds.

Split by source and question family, including paraphrases, translations and generated variants. Randomly splitting individual questions can put near-duplicates into both teaching and evaluation sets.

## Broad preparation, narrow access
A powerful general-purpose AI may be used in the offline preparation workspace. Its drafts are not automatically trusted. That does not require using a general-purpose chatbot as the child's tutor.

Maintain the full Classes 1–10 collection centrally. Enforce board, grade, curriculum version, language and educator-approved scope at retrieval time. A Class 1 session must not gain access to every record simply because those records share an embedding or keyword.

Personal history still starts empty. This shared teaching collection contains no individual child profiles. Weekly teacher notes belong in a separate protected student-history system, not in this curriculum corpus.

## Definition of useful coverage
Do not optimise for file count. For every approved concept, track whether the collection has:
- a valid curriculum mapping and reviewed prerequisite links;
- more than one appropriate explanation/representation where useful;
- guided practice and independent variations;
- known limitations and task-specific follow-up prompts;
- an authorised source trail or documented original authorship;
- a reserved evaluation family and a plan for later review.

The exact number of questions per concept should be set after editorial review; this pack does not invent a total concept count or claim complete coverage.

## First implementation batch
Enumerate the current curriculum and books across all ten grades. Then process one complete concept family end-to-end before scaling the same extraction and review workflow across grades 1–2, 3–5, 6–8 and 9–10. These are processing batches, not a reduction of the Classes 1–10 goal.

Use the three example records only to exercise the data format. They are not ready for release to children. A trained model and a production ingestion service are later outputs, not included in this pack.

## Reference links
Official curriculum catalogue: https://cbseacademic.nic.in/curriculum_2027.html
Official resource portal: https://diksha.gov.in/
Teacher-development portal: https://ciet.ncert.gov.in/nishtha
NCERT coursebook: https://ciet.ncert.gov.in/storage/app/public/files/17/Nishtha/NISHTHA_FLN_ENGLISH.pdf
NCERT e-content terms (search text retrieved; direct page timed out): https://epathshala.nic.in/wp-content/doc/book/gtextbook/textbook.htm
DIKSHA terms: https://diksha.gov.in/term-of-use.html
YouTube terms checked during discovery: https://uk.youtube.com/t/terms

Source-by-source status and exact resource URLs are in source_registry.json. This pack contains proposed engineering requirements, not a legal opinion on training rights.

